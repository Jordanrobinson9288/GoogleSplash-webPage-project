public class Car extends Machine{
    public void wipeWindShield(){
        System.out.println("Wiping windshield");
    }

    public void started(){
        System.out.println("Car started.");
    }
}
