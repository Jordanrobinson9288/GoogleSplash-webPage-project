public class Machine {
    public void started(){
        System.out.println("Machine started.");
    }

    public void stopped(){
        System.out.println("Machine stopped");
    }
}
