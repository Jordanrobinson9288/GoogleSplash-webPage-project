class Frog {
    private int id;
    private String name;

    public Frog(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public String toSpring() {
        return id + ": " + name;
    }
}

public class Main {
    public static void main(String[] args) {
//        System.out.println("Hello, World!");
//        Object obj = new Object();

//        Frog frog1 = new Frog(36, "Jordan");
//        System.out.println(frog1.toSpring());

//        Machine mach1 = new Machine();
//        mach1.started();
//        mach1.stopped();
        Car car1 = new Car();
        car1.started();
        car1.wipeWindShield();
        car1.stopped();
    }
}